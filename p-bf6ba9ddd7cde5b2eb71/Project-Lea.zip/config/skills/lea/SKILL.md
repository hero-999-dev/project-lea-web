---
name: lea
description: Work on the Lea ruleset and its measurement rig - develop or optimise Lea, propose a v9, read the shadow-arm report, switch a session between the Lea and stock arms, refresh the savings pages, or export a machine's ledger. Use whenever the user says "Lea'yı optimize edelim", "Lea'yı geliştirelim", "lea raporu", "which arm am I on", or otherwise asks to continue the Lea work - from any directory, on any machine.
---

# Lea

Lea is a ~180-token `SessionStart` hook that replaced an 11-plugin configuration, chosen by a
286-run benchmark. Beside it runs a measurement rig. This skill exists so that a session opened
**anywhere** can pick that work up, because nothing else carries it: Claude Code's memory is
scoped per working directory, so notes written in one project are invisible in the next.

## First, find out where you are

Do this before anything else. Do not guess a path, and never hardcode one - this file ships to
other machines and other user profiles.

```powershell
# The pointer every install writes. Its parent is the project root when Lea was installed
# in-project, and ~/.claude when it was installed by the collector.
Get-Content "$HOME\.claude\shadow-dir.txt" -Raw
```

Three cases, and they need different work:

| What you find | Where you are | What "optimise Lea" means here |
|---|---|---|
| the pointer's parent has `savings.py`, `NEXT.md`, `PRENSIPLER.md` | **the lab** - full project | everything below |
| the pointer exists, parent has no `savings.py` | **a collector install** | read the report, switch arms, export the ledger; the ruleset itself is not decided here |
| no pointer at all | **nothing installed** | offer to install: `Project-Lea/collector/install.ps1`, from the drive at `<drive>:\_hub\lea\`, or from `Project-Lea.zip` on the public mirror https://hero-999-dev.github.io/project-lea-web/ (behind the gate). The repository itself is private since 2026-09-06: `git clone` needs the owner's login |

## In the lab

Read these two first, in this order. They are the handover, and they are current:

1. **`NEXT.md`** - what changed last round, how each piece was verified, and the ordered backlog.
2. **`PRENSIPLER.md`** - eleven rules, each one written from a mistake that actually happened.
   Rule 1 (a change is not finished when the code is) and rule 10 (everything that leaves this
   machine is assumed lost) are the two that get broken most. Rule 9 is the most expensive: a
   difference seen in ONE block is a hypothesis, not evidence - the whole v9 programme grew out
   of reading a single 13/20 as v8's rate, when 60 samples put it at 0.75. Rule 11 is the newest
   and it decides how a generated page behaves: a published number is either the record of a
   round, pinned to the rows that produced it, or a running total - and the code has to say
   which, because the page cannot.

Then look at where the measurement stands:

```powershell
python shadow\report.py        # both arms, the pairs, and what each arm changed on disk
python shadow\arm.py           # which arm the next session will run as
```

**Every round ends with these three, and the round is not finished until all three are clean:**

```powershell
python savings.py          # banner + the two generated report pages + savings.json
python sync_payload.py     # live files -> collector payload and the published copies
python check_docs.py       # secret, leak, shipped, link, numbers, round, page, stale, mention
```

## What the numbers mean, so you do not overclaim

- The savings headline is a **projection**: a measured ratio from the benchmark times measured
  spend. It is not a measured saving, and the pages say so.
- The **paired** shadow arm can only see prompts that opened their session - 4.3% of spend on the
  account where this was measured. Replaying a conversation into the stock arm would fix that and
  costs $39.76 at the median turn, $206 at the 90th percentile, against a $4 cap. It is a price
  wall, not an oversight.
- The **wide** arm is session-level A/B on the same ledger: `python shadow/arm.py stok`, restart
  the CLI, work normally. 100% coverage, no extra spend, and *not* paired - two sessions are
  different work, so never report it as a paired result. It is also underpowered, measured on
  2026-09-04: cost per turn has a log-sd of 1.28, so resolving a 25% difference needs 518
  rows per arm - 157 for 50%, 1321 for 15% - and the headline claims -26%. It is an
  accumulator, not the route to a measured headline.
- The **per-label medians** `report.py` prints for the wide arm are not a comparison at all. The
  arms run different model mixes, and the labels sort sessions by age: a banner never leaves a
  transcript, so a session that met Lea once is `lea` on Lea days and `other-carried-lea` on
  stock days, and `other` keeps only the young sessions. Read the **like with like** block under
  the table instead - same model, same depth band, the experiment day as the unit, days
  shuffled. On 2026-10-13 that turned a raw 2.19x into 0.95x, inside a shuffle band of
  0.50..1.98: no visible difference, and nothing under about 2x would have been visible. One
  reading; by rule 9 it is a hypothesis.
- 70% of real spend is re-reading the conversation, 12% is output. A proposal that only shortens
  Lea's replies is aiming at the small number; **turn count** is the lever.

## Before proposing a v9

Do not. Not until there is evidence, and in practice that means a benchmark round: fixed
tasks, hidden tests, n=20 per arm, both arms the same day. It is the only instrument here
with the power to settle it. A fixed task with a BINARY outcome needs n=20; every continuous
measure on real work needs hundreds - the paired arm sees 4.3% of spend, turn count needs
n=226, the wide arm n=518. Watch `pairs N/20`, but do not wait on it. That is how v8 was decided: rewriting one paragraph,
the exception clause from permission to obligation, moved the hard round from 4/20 to 13/20 -
an effect large enough for n=20 to settle.

**One was tried and rejected: `lea-v9c`, 2026-09-05, 92 cells and $9.23.** 36/40 against a
same-day `lea-v8` control at 32/40, two-sided Fisher p=0.3482, and the bar was written before the
round. Read `rapor-v9.html` before proposing anything in that direction - an unpublished negative
result is how the same hypothesis gets bought twice. The round's own finding matters more than its
verdict: **13/20 was never v8's rate.** The same bytes scored 13/20, 15/20 and 17/20 in three
blocks, pooling to 45/60 = 0.75, and that scatter is what one rate looks like at n=20. The whole
v9 programme grew out of reading a single block as a rate.

While Lea is the thing being measured, what must not change is **the banner it emits** -
that is the whole independent variable, and the file around it is not. Checked on
2026-09-04: the live `~/.claude/hooks/lea.js` and the measured `bench/hooks/lea-v8.js`
differ by 43 lines, every one of them a comment, and emit the same 226 words. So compare
output, not files - the rule used to say byte-identical, which was already false and would
have sent someone to "fix" a difference that changes nothing.

**A v10 was looked for in the transcripts on 2026-10-14, and it is not a paragraph.**
`python shadow/sessions.py` counts what the model did per API turn in every recorded session.
What a paragraph could reach is already small: look-only turns that could have been batched are
2.6% of Lea's Opus turns, repeated reads 4.2% of reads, repeated commands 0.1%, and the median
reply is 122 words against stock's 190 - the banner's own rules are being followed. What a turn
costs is what it RE-READS: the median Opus turn carries 278k tokens under Lea and 469k without,
because Claude Code lets a conversation grow to the 1M window before compacting (27 observed
compactions, median 863k before, 60k after). `python shadow/context_cap.py` replays the recorded
sessions under a smaller `autoCompactWindow` - a settings.json key, 100000 to 1000000 - and at
200k projects 0.57x for Lea/Opus and 0.33x for stock/Opus, compaction and cache re-write costs
included. A projection: measured tokens and prices, an assumed session, and no measure of what a
summary forgets. So the candidate is **v8's banner, unchanged, plus a window** - a config change,
which leaves every banner measurement standing. Read NEXT.md for whether it was switched on and
what it was predicted to do before it was.

A banner candidate is a candidate only if its banner differs from v8 in ONE paragraph and nothing
else. The three v9 candidates were verified that way: paragraph 5 of 6, +25 / +12 / +29
words, same six paragraphs.

## Things that will bite you

- **Hooks are read at session start.** Anything you change in `settings.json` - including the arm
  switch - does not apply until the CLI is restarted, and the current session keeps recording
  under the old label.
- **Passwords live in one file on the machine that owns them**, outside every repository, and
  never on the drive. `check_docs.py`'s `secret` pass fails the build if one leaks.
- **Project-Lea is private since 2026-09-06, and pushing it publishes nothing.** The only public
  copy is a second repository, `project-lea-web`: the report pages, the guides rendered to HTML
  and a zip of the hook, the config and the collector, behind the password gate. It is rebuilt by
  `python publish_web.py <clone of project-lea-web>` from the lab root, then committed and pushed
  there. It sat untouched from 2026-09-06 to 2026-10-14 because nothing in the lab knew it
  existed - so "push" means both repositories. That mirror is public: the gate stops a link from
  being casually shared and nothing more; nothing that matters if it is read goes behind it.
- **Push through gh's credentials.** Two GitHub accounts are logged in on this machine and the
  credential manager offers the wrong one, which GitHub answers with "Repository not found":
  `git -c credential.helper= -c credential.helper='!gh auth git-credential' push origin main`.
