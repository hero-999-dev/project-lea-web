#!/usr/bin/env node
// The shadow arm's fence (2026-09-29).
//
// Every shadow run works in a copy (runs/<id>/work), but a copy only protects the tree it was made
// of. A prompt about a project somewhere else on disk sends the agent there by absolute path, and
// on 2026-09-29 the replay of "Ideas for Nebula" edited the real Nebula repo alongside the live
// session - the two overwrote each other's files. On 2026-09-27 another replay ran a release step
// there too. The copy was never the problem; nothing stopped the agent from leaving it.
//
// This is a PreToolUse hook the runner adds to every shadow run's settings. It lets the agent read
// anywhere, and write only inside its own copy, the Shadow Workspace, and the temp directory. A
// project that lives elsewhere is brought in with workspace.ps1, which mirrors it into its own
// "Work N" folder (one per project) - the deny message says so, which is all the agent needs.
//
// It is a fence, not a sandbox: a program the agent starts (a test, a build) can still write where
// it likes. It stops the agent's own edits and the obvious commands, which is what went wrong.
//
//   node guard.js                      as the hook: reads the tool call on stdin
//   node guard.js --compose in out     writes `in` settings plus this hook to `out`
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

const WORKSPACE_TOOL = path.join(__dirname, 'workspace.ps1');

/** 'C:/x', '/c/x', 'c:\\x\\' -> 'c:\\x' - one spelling, for prefix tests. */
function norm(p) {
  let s = String(p || '').trim().replace(/^["']|["']$/g, '');
  if (!s) return '';
  const home = os.homedir();
  s = s.replace(/^~(?=[\\/]|$)/, home).replace(/^\$HOME(?=[\\/]|$)/i, home)
    .replace(/^%USERPROFILE%/i, home).replace(/^\$env:USERPROFILE/i, home);
  const m = s.match(/^\/([a-zA-Z])(\/.*)?$/);
  if (m) s = `${m[1]}:${m[2] || '/'}`;
  s = s.replace(/\//g, '\\');
  if (!/^[a-zA-Z]:\\/.test(s) && !/^\\\\/.test(s)) return '';
  return path.win32.normalize(s).replace(/\\+$/, '').toLowerCase();
}

function allowedRoots() {
  const list = String(process.env.LEA_SHADOW_ALLOW || '').split(';').map(norm).filter(Boolean);
  list.push(norm(os.tmpdir()));
  return [...new Set(list)];
}

function inside(p, roots) {
  const n = norm(p);
  if (!n) return true;                       // relative: resolved by the caller, or harmless
  return roots.some((r) => n === r || n.startsWith(r + '\\'));
}

/** Absolute paths a shell command mentions, quoted ones whole. */
function pathsIn(command) {
  const out = [];
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  let m;
  while ((m = re.exec(command))) {
    const raw = (m[1] ?? m[2] ?? m[3] ?? '').replace(/^[<>=(]+|[);,]+$/g, '');
    for (const piece of raw.split(/(?<=\S)(?=[a-zA-Z]:[\\/])/)) {
      if (/^([a-zA-Z]:[\\/]|\/[a-zA-Z]\/|~[\\/]|\$HOME|%USERPROFILE%|\$env:USERPROFILE|\\\\)/i.test(piece)) out.push(piece);
    }
  }
  return out;
}

const READ_VERBS = new Set(['cd', 'pushd', 'popd', 'ls', 'dir', 'cat', 'type', 'head', 'tail', 'grep', 'egrep', 'rg',
  'find', 'wc', 'stat', 'file', 'du', 'tree', 'echo', 'pwd', 'realpath', 'readlink', 'sort', 'uniq', 'cut', 'less',
  'more', 'sha256sum', 'md5sum', 'diff', 'cmp', 'test', '[', 'true', 'false', 'timeout',
  'get-childitem', 'gci', 'get-content', 'gc', 'select-string', 'sls', 'test-path', 'get-item', 'gi',
  'resolve-path', 'set-location', 'sl', 'get-filehash', 'measure-object', 'select-object', 'where-object',
  'format-table', 'out-string', 'write-output']);
const READ_GIT = new Set(['log', 'status', 'diff', 'show', 'ls-files', 'rev-parse', 'branch', 'blame', 'describe', 'shortlog', 'cat-file']);

/** Is this one segment of a command a read? */
function readOnly(segment) {
  const words = segment.trim().replace(/^(\w+=\S*\s+)+/, '').split(/\s+/).filter(Boolean);
  if (!words.length) return true;
  let verb = words[0].replace(/^["'(]+/, '').toLowerCase();
  if (verb === 'timeout' && words.length > 2) verb = words[2].toLowerCase();
  if (/\bworkspace\.ps1\b/i.test(segment)) return true;     // the way in: copies, never writes back
  if (verb === 'git') {
    const sub = words.slice(1).find((w) => !w.startsWith('-') && !/^[a-z]:|^\//i.test(w) && w !== 'C');
    return READ_GIT.has(String(sub || '').toLowerCase()) && !/\s-C\s+\S+\s+(?!log|status|diff|show)/.test(segment);
  }
  if (verb === 'sed') return !/\s-i\b|--in-place/.test(segment);
  if (verb === 'find') return !/-delete|-exec|-execdir|-ok\b/.test(segment);
  if (!READ_VERBS.has(verb)) return false;
  // A redirect into a file is a write, whatever the verb.
  return !/(^|[^0-9&])>{1,2}\s*(?!\/dev\/null|\$null|&)/.test(segment);
}

const OUTWARD = [
  /\bgit\s+(-C\s+\S+\s+)?push\b/i, /\bgh\s+(release|pr|repo|api)\b/i, /\bnpm\s+(publish|run\s+push)\b/i,
  /\bsync-flash\b/i, /\bflash-sync\.ps1\b/i, /\bgit\s+(-C\s+\S+\s+)?(tag|commit)\b.*&&.*\bpush\b/i,
];

function deny(reason) {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: reason },
  }));
  process.exit(0);
}

const HOW = (roots) => 'This is a Lea shadow run: it works in a copy and may change nothing outside '
  + `${roots.filter((r) => r !== norm(os.tmpdir())).join(' or ')} (and the temp folder). `
  + 'If the task is about a project elsewhere on disk, bring it in first: '
  + `powershell -NoProfile -File "${WORKSPACE_TOOL}" -Path "<the project folder>" - it mirrors the project `
  + 'into its own Work folder (one per project) and prints that folder. Then do all the work there. '
  + 'Reading anywhere (ls, cat, grep, git log) is allowed.';

function decide(call) {
  const roots = allowedRoots();
  const tool = call.tool_name || '';
  const input = call.tool_input || {};
  const cwd = call.cwd || process.cwd();
  if (['Write', 'Edit', 'MultiEdit', 'NotebookEdit'].includes(tool)) {
    const target = input.file_path || input.notebook_path || '';
    const abs = norm(target) ? target : path.resolve(cwd, target);
    if (!inside(abs, roots)) deny(`${target} is outside this run's copy. ${HOW(roots)}`);
    return;
  }
  if (tool !== 'Bash' && tool !== 'PowerShell') return;
  const command = String(input.command || '');
  for (const re of OUTWARD) if (re.test(command)) deny(`"${command.slice(0, 80)}" reaches outside this machine or onto the flash drive; a shadow run never does. ${HOW(roots)}`);
  // Where the command starts matters as much as what it names: a relative write from a cwd
  // outside the copy is a write outside.
  const outside = pathsIn(command).filter((p) => !inside(p, roots));
  if (!inside(cwd, roots)) outside.push(cwd);
  if (!outside.length) return;
  const segments = command.split(/&&|\|\||[;|\n]/);
  if (segments.every(readOnly)) return;
  deny(`the command touches ${outside[0]}, outside this run's copy, and does more than read. ${HOW(roots)}`);
}

/** `in` settings (a shadow config) plus this hook, written to `out`. */
function compose(inFile, outFile) {
  const settings = JSON.parse(fs.readFileSync(inFile, 'utf8').replace(/^\uFEFF/, ''));
  settings.hooks = settings.hooks || {};
  const entry = {
    matcher: 'Write|Edit|MultiEdit|NotebookEdit|Bash|PowerShell',
    hooks: [{ type: 'command', command: `node "${__filename}"`, timeout: 15 }],
  };
  settings.hooks.PreToolUse = [...(settings.hooks.PreToolUse || []), entry];
  fs.writeFileSync(outFile, JSON.stringify(settings, null, 2));
}

if (require.main === module) {
  if (process.argv[2] === '--compose') {
    compose(process.argv[3], process.argv[4]);
  } else {
    let raw = '';
    process.stdin.on('data', (d) => { raw += d; });
    process.stdin.on('end', () => {
      let call = {};
      try { call = JSON.parse(raw || '{}'); } catch { process.exit(0); }
      decide(call);
      process.exit(0);
    });
  }
}

module.exports = { norm, inside, pathsIn, readOnly, decide, compose, OUTWARD };
