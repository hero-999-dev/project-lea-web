"""Choose which arm the next session runs as: Lea, or the stock config it is measured against.

    python shadow/arm.py               # which arm is armed, and what the schedule says
    python shadow/arm.py lea           # next session runs with Lea
    python shadow/arm.py stok          # next session runs without it
    python shadow/arm.py --flip        # whichever it is not
    python shadow/arm.py --auto        # whichever the alternating schedule says today
    python shadow/arm.py --auto --dry-run    # what --auto would do, changing nothing
    python shadow/arm.py --schedule-json     # the rule itself, for whatever drives it

WHY THIS EXISTS
---------------
The shadow arm answers each session's opening prompt a second time with a stock config, and that
is the only paired evidence there is. It is also structurally small: only a prompt that opens its
session can be paired, and those are 4.3% of what this account actually spends. Everything after
the first prompt - which is where the work happens, and where 70% of the money goes on re-reading
the conversation - it cannot see at all.

Giving the stock arm the same conversation would fix the coverage and is not affordable: the
median turn here carries 4.0M tokens of conversation, which a fresh run pays for as cache-write,
$39.76 once, $206 at the 90th percentile, against a $4 per-run cap. Measured, not guessed.

So the coverage problem is solved from the other end. The Stop hook already prices EVERY turn and
already records which ruleset produced it (`lea_config`). Run some sessions without Lea and the
same ledger separates the two arms by itself: 100% of prompts, no extra spend, and the sessions
being measured are the real ones rather than their first line.

What it costs instead is cleanliness. Two sessions are not the same task, so this is not a paired
comparison and must never be reported as one - it needs n, and it needs the work to be normalised
per prompt. report.py prints it that way.

WHY IT ALTERNATES BY DAY
------------------------
The wide arm was first run as one long block, and that was measured on 2026-09-05 to be the
wrong shape:

    08-30 -> 09-03     lea 140    stok   0
    09-04              lea   8    stok   5    (30 more discarded as other-carried-lea)
    09-05              lea   0    stok  13

Compared that way, the difference between the two arms and the difference between one week and
the next are the same number, and no amount of further collection separates them. It is the
confound the v9 round paid for a same-day control to avoid, one level out - PRENSIPLER 6, and
PRENSIPLER 9 for why one block is never a rate.

So the arm alternates: one experiment day Lea, the next stock, on every install that writes this
ledger. A time effect then falls on both arms equally instead of entirely on one.

The schedule is fixed in this file rather than decided each morning, because a cadence chosen
after looking at the numbers is not a cadence. There is nothing in it to tune after the fact: it
is parity of whole blocks since a fixed date, and the date is only a phase - any other one gives
the same alternation, shifted.

An experiment day starts at 06:00 local, not at midnight. This account demonstrably works past
midnight, and a midnight boundary would hand the two halves of one working night to two different
arms - which is the very thing being avoided, in miniature.

Period 2 does not alias with the week: 2 and 7 are coprime, so over any 14 days each weekday
falls once in each arm. test-arm-schedule.py measures that rather than asserting it.

This does not make the wide arm powerful. It stays what report.py says it is - an accumulator,
needing ~518 rows per arm to resolve 25% - and the route to a measured headline is still a
benchmark round. Alternating only makes the rows it does collect mean something.

WHAT DRIVES IT
--------------
Nothing, on its own. `--auto` obeys the calendar and is idempotent; something has to call it, and
it has to be called BEFORE the CLI starts, because hooks are read at session start. On Windows
that is a scheduled task - `shadow/schedule-arm.ps1` registers one - but any scheduler will do.
Every `--auto` run appends one line to `arm-schedule.log` beside the ledger, so whether the driver
actually fired is a fact on disk rather than an assumption.

WHAT IT CHANGES
---------------
One entry in each install's settings.json: the SessionStart hook that loads lea.js. Nothing is
deleted - the hook file stays on disk, the entry is moved aside under a key Claude Code ignores,
so switching back is exact rather than reconstructed. The shadow arm's own two hooks are left
alone: the ledger must keep recording whichever arm you are on, or the experiment has one side.
"""
import io
import json
import os
import re
import shutil
import sys
from datetime import date, datetime, timedelta

# A scheduled run has no console. Under pythonw.exe sys.stdout is None, and the first print()
# after the flip would raise - leaving the arm switched and the log line, which is the only proof
# the driver fired at all, never written. And a run piped to a file must not die printing a path
# with a Turkish name in it, because that failure reads as "no output".
if sys.stdout is None:
    sys.stdout = sys.stderr = io.open(os.devnull, 'w', encoding='utf-8')
else:
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                   # noqa: BLE001 - older interpreters simply do without
        pass

HOME = os.environ.get('USERPROFILE') or os.path.expanduser('~')
SETTINGS = os.path.join(HOME, '.claude', 'settings.json')

# The alternating schedule, fixed in advance. EPOCH is itself a Lea day; it was the arm actually
# armed on that date, so writing the rule down changed nothing about the day it was written.
EPOCH = date(2026, 9, 5)
BLOCK_DAYS = 1
DAY_STARTS_AT_HOUR = 6

# Where a disabled entry is parked, and why it is not in settings.json.
#
# It was, under an unknown top-level key, on the assumption that Claude Code ignores keys it does
# not recognise. It does not: a hook-shaped entry declared anywhere but under "hooks" makes the
# CLI reject the ENTIRE file - "Files with errors are skipped entirely, not just the invalid
# settings" - so parking Lea there took the shadow arm's own two hooks down with it, silently,
# until the next start printed a settings error. Found the first time the switch was used for
# real.
#
# So the entry is parked beside the ledger instead, where this project's state already lives, and
# settings.json is left a valid settings file. Keeping the original object rather than a flag
# still matters: turning Lea back on restores exactly what was there - matcher, timeout,
# statusMessage - instead of a plausible reconstruction.
PARK_KEY = '_leaSessionStartDisabled'      # the old location, migrated on sight


# ---------------------------------------------------------------- where things are


def shadow_dir():
    """The ledger's directory, through the pointer every hook already uses."""
    try:
        p = io.open(os.path.join(HOME, '.claude', 'shadow-dir.txt'), encoding='utf-8').read().strip()
        if p and os.path.isdir(p):
            return p
    except Exception:
        pass
    return os.path.join(HOME, '.claude')


def shadow_config():
    try:
        return json.load(io.open(os.path.join(shadow_dir(), 'config.json'), encoding='utf-8-sig'))
    except Exception:
        return {}


def who(settings_path):
    """The install's name - the profile directory that owns this settings.json."""
    return os.path.basename(os.path.dirname(os.path.dirname(os.path.abspath(settings_path))))


def profiles():
    """Every settings.json the switch has to reach, this install first.

    Leaving one install pinned to one arm makes the arm difference and the difference between two
    Windows profiles the same number - the confound the schedule exists to remove, moved one level
    out, and NEXT.md's item 0 warns about exactly it. The installs that write this ledger are
    already named in shadow/config.json's `accounts` map, so that is the list, resolved as
    siblings of this profile. A machine with no map has one install and that is this one, which is
    why an empty map is the safe default rather than a special case.
    """
    out = [SETTINGS]
    seen = {os.path.normcase(os.path.abspath(SETTINGS))}
    users_dir = os.path.dirname(HOME)
    for name in sorted((shadow_config().get('accounts') or {})):
        p = os.path.join(users_dir, name, '.claude', 'settings.json')
        key = os.path.normcase(os.path.abspath(p))
        if key not in seen and os.path.isfile(p):
            seen.add(key)
            out.append(p)
    return out


def park_file(settings_path=None):
    """Beside the ledger, one file per install.

    It used to be a single `arm-parked.json`, which was right for as long as only this profile was
    ever switched. It stops being right the moment the schedule flips a second install from here:
    the two parks resolve through THIS process's HOME, so the second would have been written over
    the first and restoring would have handed one profile's hook entry to both. The primary
    install keeps the old name, so a park written before this change is still found.
    """
    settings_path = settings_path or SETTINGS
    d = shadow_dir()
    if os.path.normcase(os.path.abspath(settings_path)) == os.path.normcase(os.path.abspath(SETTINGS)):
        return os.path.join(d, 'arm-parked.json')
    safe = re.sub(r'[^A-Za-z0-9._-]', '_', who(settings_path)) or 'other'
    return os.path.join(d, 'arm-parked-%s.json' % safe)


def log_file():
    return os.path.join(shadow_dir(), 'arm-schedule.log')


# ---------------------------------------------------------------- the schedule


def experiment_day(now=None):
    """Which experiment day a moment belongs to. Anything before 06:00 still belongs to the day
    before, so a session that runs past midnight is not split across two arms."""
    return ((now or datetime.now()) - timedelta(hours=DAY_STARTS_AT_HOUR)).date()


def scheduled_arm(day=None):
    """'lea' or 'stok', by parity of whole blocks since EPOCH. Defined before EPOCH too - the
    floor division keeps alternating backwards - so no date is a special case."""
    day = day if day is not None else experiment_day()
    return 'lea' if ((day - EPOCH).days // BLOCK_DAYS) % 2 == 0 else 'stok'


def next_flip(now=None):
    """The moment the scheduled arm next changes. Derived by walking the schedule rather than by
    adding BLOCK_DAYS, so it stays true if the block length ever changes."""
    now = now or datetime.now()
    day = experiment_day(now)
    here = scheduled_arm(day)
    d = day + timedelta(days=1)
    while scheduled_arm(d) == here:
        d += timedelta(days=1)
    return datetime.combine(d, datetime.min.time()) + timedelta(hours=DAY_STARTS_AT_HOUR)


# ---------------------------------------------------------------- settings.json


def read_park(cfg, settings_path=None):
    """The parked entry, from the file - or from the old settings key, so an install that was
    switched off by the previous version can still be switched back on."""
    if PARK_KEY in cfg:
        return cfg[PARK_KEY]
    try:
        return json.load(io.open(park_file(settings_path), encoding='utf-8-sig'))
    except Exception:
        return None


def write_park(entries_, settings_path=None):
    path = park_file(settings_path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, 'w', encoding='utf-8') as fh:
        json.dump(entries_, fh, indent=2, ensure_ascii=False)


def clear_park(cfg, settings_path=None):
    cfg.pop(PARK_KEY, None)
    try:
        os.remove(park_file(settings_path))
    except OSError:
        pass


def load(settings_path=None):
    with io.open(settings_path or SETTINGS, encoding='utf-8-sig') as fh:
        return json.load(fh)


def save(cfg, settings_path=None):
    # One backup per change, and the name has to prove it. Seconds alone do not: the test flipped
    # the arm five times inside one second and four of the five backups overwrote each other, so
    # a suffix runs until the name is free. A backup that silently is not there is worse than no
    # backup, because it is the thing you reach for after a bad write.
    settings_path = settings_path or SETTINGS
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    path = settings_path + '.bak-' + stamp
    n = 2
    while os.path.exists(path):
        path = '%s.bak-%s-%d' % (settings_path, stamp, n)
        n += 1
    shutil.copy2(settings_path, path)
    with io.open(settings_path, 'w', encoding='utf-8') as fh:
        json.dump(cfg, fh, indent=2, ensure_ascii=False)
    return path


def entries(cfg):
    return (cfg.get('hooks') or {}).get('SessionStart') or []


def is_lea(cfg):
    """Lea is on when a SessionStart hook actually points at lea.js.

    Read the same way the Stop hook reads it (liveConfig()), so the ledger's `lea_config` column
    and this answer cannot disagree about what was running.
    """
    return 'lea.js' in json.dumps(entries(cfg))


def state(cfg):
    plugins = len([v for v in (cfg.get('enabledPlugins') or {}).values() if v])
    if is_lea(cfg):
        return 'lea' if not plugins else 'lea+%dplugins' % plugins
    return 'other+%dplugins' % plugins if plugins else 'other'


def turn_off(cfg, settings_path=None):
    hooks = cfg.setdefault('hooks', {})
    keep, parked = [], []
    for e in entries(cfg):
        (parked if 'lea.js' in json.dumps(e) else keep).append(e)
    if not parked:
        return False
    if keep:
        hooks['SessionStart'] = keep
    else:
        hooks.pop('SessionStart', None)
    write_park(parked, settings_path)
    cfg.pop(PARK_KEY, None)          # never leave the old shape behind
    return True


def turn_on(cfg, settings_path=None):
    parked = read_park(cfg, settings_path)
    if not parked:
        return False
    hooks = cfg.setdefault('hooks', {})
    hooks['SessionStart'] = list(parked) + [e for e in entries(cfg)
                                            if 'lea.js' not in json.dumps(e)]
    clear_park(cfg, settings_path)
    return True


def set_arm(settings_path, want):
    """Put one install on `want`. Returns (before, after, backup path or None when already there).

    Raises LookupError when the move is impossible - a Lea entry that was never installed cannot
    be restored, and saying so is the only honest answer. It is raised rather than printed so that
    one unswitchable install cannot quietly decide the outcome for the others.
    """
    cfg = load(settings_path)
    before = state(cfg)
    if (want == 'lea') == before.startswith('lea'):
        return before, before, None
    ok = turn_on(cfg, settings_path) if want == 'lea' else turn_off(cfg, settings_path)
    if not ok:
        raise LookupError('no lea.js entry to %s' % ('restore' if want == 'lea' else 'park'))
    backup = save(cfg, settings_path)
    return before, state(load(settings_path)), backup


# ---------------------------------------------------------------- commands


def apply_to_all(want, dry=False):
    """Move every install to `want`. Returns (lines, changed, failed)."""
    lines, changed, failed = [], 0, 0
    for path in profiles():
        name = who(path)
        try:
            before = state(load(path))
        except Exception as exc:                                    # noqa: BLE001
            lines.append('  %-10s UNREADABLE - %s' % (name, exc))
            failed += 1
            continue
        if dry:
            verb = 'stays' if (want == 'lea') == before.startswith('lea') else '-> %s' % want
            lines.append('  %-10s %-16s %s' % (name, before, verb))
            continue
        try:
            b, a, backup = set_arm(path, want)
        except LookupError as exc:
            lines.append('  %-10s %-16s FAILED - %s' % (name, before, exc))
            failed += 1
            continue
        if backup:
            changed += 1
            lines.append('  %-10s %s -> %s   (yedek: %s)' % (name, b, a, os.path.basename(backup)))
        else:
            lines.append('  %-10s %-16s zaten' % (name, b))
    return lines, changed, failed


def note_run(day, want, changed, failed, lines):
    """One line per --auto run, appended beside the ledger.

    Whether the driver actually fires is the single thing that can silently break the schedule,
    and it cannot be read off settings.json: a task that never ran and a day that needed no change
    leave the same file behind. So the run itself is recorded, not just its effect.
    """
    stamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
    detail = ' | '.join(' '.join(l.split()) for l in lines)
    try:
        with io.open(log_file(), 'a', encoding='utf-8') as fh:
            fh.write('%s day=%s want=%s changed=%d failed=%d | %s\n'
                     % (stamp, day, want, changed, failed, detail))
    except Exception:                                               # noqa: BLE001
        pass                       # a log that cannot be written must not fail the flip


def last_run():
    try:
        lines = [l for l in io.open(log_file(), encoding='utf-8').read().splitlines() if l.strip()]
        return lines[-1] if lines else None
    except Exception:
        return None


def run_auto(dry=False):
    day = experiment_day()
    want = scheduled_arm(day)
    lines, changed, failed = apply_to_all(want, dry=dry)
    print('deney gunu %s (%02d:00\'da basladi) -> %s' % (day, DAY_STARTS_AT_HOUR, want))
    for l in lines:
        print(l)
    if dry:
        print('\n--dry-run: hicbir sey degismedi.')
        return 0
    note_run(day, want, changed, failed, lines)
    print('\n%d kurulum degisti, %d basarisiz. Sonraki degisim: %s'
          % (changed, failed, next_flip().strftime('%Y-%m-%d %H:%M')))
    if changed:
        print('Hook\'lar oturum acilisinda okunuyor: acik CLI oturumlari hala eski kolu kaydeder.')
    return 1 if failed else 0


def show():
    cfg = load()
    now = state(cfg)
    day = experiment_day()
    want = scheduled_arm(day)

    print('su an: %s' % now)
    print('sonraki oturum bu kolla acilir.\n')
    print('program: %d gunluk donusumlu blok - deney gunu %s (%02d:00\'da basladi) -> %s'
          % (BLOCK_DAYS, day, DAY_STARTS_AT_HOUR, want))
    print('sonraki degisim: %s -> %s'
          % (next_flip().strftime('%Y-%m-%d %H:%M'), 'stok' if want == 'lea' else 'lea'))

    paths = profiles()
    if len(paths) > 1:
        print('\nkurulumlar (hepsi ayni kolda olmali - yoksa kol farki profil farkiyla karisir):')
        for p in paths:
            try:
                print('  %-10s %s' % (who(p), state(load(p))))
            except Exception as exc:                                # noqa: BLE001
                print('  %-10s UNREADABLE - %s' % (who(p), exc))

    if (want == 'lea') != now.startswith('lea'):
        print('\nUYARI: program %s diyor, bu kurulum %s. Bir sapma, hata degil - sonraki'
              ' --auto kosusu programa dondurur.' % (want, now))

    seen = last_run()
    print('\nson otomatik kosu: %s' % (seen or 'HIC - programi hicbir sey suruklemiyor.'
                                              ' Kaydet: pwsh -File shadow\\schedule-arm.ps1'))

    other = 'stok' if now.startswith('lea') else 'lea'
    print('\nelle degistirmek icin, hangi dizinde olursan ol:')
    print('  python "%s" %s' % (os.path.abspath(__file__), other))
    print('\nsonra CLI\'i yeniden baslat - hook\'lar oturum acilisinda okunuyor.')


def main(argv):
    rest = [a for a in argv[1:] if a not in ('--dry-run', '-n')]
    dry = len(rest) != len(argv[1:])
    want = (rest[0].lower() if rest else '')

    if want in ('--schedule-json',):
        # The scheduler has to fire on the same boundary the rule uses, and a second copy of "6"
        # in a .ps1 is exactly how the two drift apart. It reads the number from here instead.
        print(json.dumps({'epoch': EPOCH.isoformat(), 'block_days': BLOCK_DAYS,
                          'day_starts_at_hour': DAY_STARTS_AT_HOUR,
                          'today': experiment_day().isoformat(),
                          'arm': scheduled_arm(), 'next_flip': next_flip().isoformat()}))
        return 0

    if want in ('--auto', 'auto'):
        return run_auto(dry=dry)

    if not want:
        show()
        return 0

    now = state(load())
    if want in ('--flip', 'flip'):
        want = 'stok' if now.startswith('lea') else 'lea'
    elif want in ('lea', 'on', 'ac'):
        want = 'lea'
    elif want in ('stok', 'stock', 'off', 'kapat'):
        want = 'stok'
    else:
        print(__doc__)
        return 2

    lines, changed, failed = apply_to_all(want, dry=dry)
    for l in lines:
        print(l)
    if dry:
        print('\n--dry-run: hicbir sey degismedi.')
        return 0

    day = experiment_day()
    due = scheduled_arm(day)
    if due != want:
        print('\nNOT: program bugun (%s) %s diyor. Elle %s\'a alindi; sonraki --auto kosusu'
              ' geri alir.' % (day, due, want))
    if changed:
        print('\nHook\'lar oturum acilisinda okunuyor: CLI\'i yeniden baslat, yoksa bu oturum'
              ' hala %s olarak kaydeder.' % now)
    elif not failed:
        print('\nzaten %s' % want)
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
