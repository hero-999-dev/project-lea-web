# A project brought into the Shadow Workspace (2026-09-29).
#
# A shadow run may not change anything outside its copy (guard.js). When its prompt is about a
# project somewhere else on disk, this is how the project comes in: it is mirrored into its own
# "Work N" folder under workspace_root - one folder per project, kept between runs, so Nebula is
# always "Work 1", Pixel Pomo "Work 2" and so on, and a second run on the same project only copies
# what changed. The folder is the shadow's to break; the real project is never written.
#
# Left out of every copy: the project's git history (nothing is pushed from a copy, and there is
# nothing to push), and whatever holds notes or private data - a copy that a later delete in the
# real project cannot reach is the hole the owner closed on 2026-09-27 ("deleted is deleted").
#
#   powershell -NoProfile -File workspace.ps1 -Path <project folder>      prints the Work folder
#   powershell -NoProfile -File workspace.ps1 -List                        the project -> Work map
param(
    [string]$Path,
    [switch]$List
)
$ErrorActionPreference = 'Stop'
$Shadow = $PSScriptRoot
$cfg = Get-Content (Join-Path $Shadow 'config.json') -Raw | ConvertFrom-Json

$Root = "$($cfg.workspace.root)"
if (-not $Root) { $Root = Join-Path (Split-Path $Shadow -Parent) 'Shadow Workspace' }
New-Item -ItemType Directory -Force -Path $Root | Out-Null
$MapFile = Join-Path $Root 'workspaces.json'

function Read-Map {
    $map = [ordered]@{}
    if (Test-Path $MapFile) {
        $j = Get-Content $MapFile -Raw | ConvertFrom-Json
        foreach ($p in $j.PSObject.Properties) { $map[$p.Name] = "$($p.Value)" }
    }
    return $map
}

if ($List) { Read-Map | ConvertTo-Json; exit 0 }
if (-not $Path) { [Console]::Error.WriteLine('give -Path <project folder>'); exit 2 }

$src = (Resolve-Path -LiteralPath $Path).ProviderPath.TrimEnd('\')
# A home directory or a drive is not a project, and mirroring one would copy a whole profile.
$homes = @($HOME, $env:USERPROFILE, (Split-Path $HOME -Parent)) | Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') }
if ($src -match '^[A-Za-z]:$' -or $homes -contains $src) {
    [Console]::Error.WriteLine("$src is a home directory or a drive, not a project. Give the project's own folder.")
    exit 2
}
if ($src.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase)) {
    Write-Output $src      # already a Work folder
    exit 0
}

$map = Read-Map
$key = $map.Keys | Where-Object { $_ -ieq $src } | Select-Object -First 1
if ($key) { $name = $map[$key] }
else {
    # The next free "Work N": one the map does not give to another project. An empty folder the
    # owner made by hand (Work 1, 2026-09-29) is free.
    $taken = @($map.Values)
    $n = 1
    while ($taken -contains "Work $n") { $n++ }
    $name = "Work $n"
    $map[$src] = $name
    $map | ConvertTo-Json | Set-Content -Path $MapFile -Encoding UTF8
}
$dest = Join-Path $Root $name
if (-not $dest.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase)) { [Console]::Error.WriteLine('refusing a Work folder outside the workspace'); exit 2 }
New-Item -ItemType Directory -Force -Path $dest | Out-Null

$dirs = @($cfg.workspace.exclude_dirs) + @('.git')
# Not copy.exclude_globs: that list drops pictures and PDFs, which a project needs to build.
$files = @($cfg.workspace.exclude_globs) | Where-Object { $_ }
# robocopy reads a directory NAME as "any directory with that name"; full paths are not needed.
$rc = @($src, $dest, '/MIR', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/XJ', '/XD') + $dirs + @('/XF') + $files
& robocopy @rc | Out-Null
$code = $LASTEXITCODE
if ($code -ge 8) { [Console]::Error.WriteLine("robocopy failed ($code) copying $src"); exit 1 }

@{ source = $src; copied = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); by = 'shadow workspace.ps1' } |
    ConvertTo-Json | Set-Content -Path (Join-Path $dest '.lea-workspace.json') -Encoding UTF8
Write-Output $dest
exit 0
